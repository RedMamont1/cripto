import Link from "next/link"

export function Navigation() {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-[#0A0A0A] border-b border-gray-800 p-4">
      <ul className="flex space-x-6 justify-center">
        <li>
          <Link
            href="/"
            className="px-4 py-2 rounded-md text-cyan-400 hover:text-cyan-300 transition-all duration-300 hover:shadow-[0_0_15px_rgba(0,255,255,0.5)] hover:bg-cyan-400/10"
          >
            Home
          </Link>
        </li>
        <li>
          <Link
            href="/learn"
            className="px-4 py-2 rounded-md text-pink-400 hover:text-pink-300 transition-all duration-300 hover:shadow-[0_0_15px_rgba(255,105,180,0.5)] hover:bg-pink-400/10"
          >
            Learn
          </Link>
        </li>
        <li>
          <Link
            href="/developers"
            className="px-4 py-2 rounded-md text-cyan-400 hover:text-cyan-300 transition-all duration-300 hover:shadow-[0_0_15px_rgba(0,255,255,0.5)] hover:bg-cyan-400/10"
          >
            Developers
          </Link>
        </li>
        <li>
          <Link
            href="/solutions"
            className="px-4 py-2 rounded-md text-pink-400 hover:text-pink-300 transition-all duration-300 hover:shadow-[0_0_15px_rgba(255,105,180,0.5)] hover:bg-pink-400/10"
          >
            Solutions
          </Link>
        </li>
        <li>
          <Link
            href="/network"
            className="px-4 py-2 rounded-md text-cyan-400 hover:text-cyan-300 transition-all duration-300 hover:shadow-[0_0_15px_rgba(0,255,255,0.5)] hover:bg-cyan-400/10"
          >
            Network
          </Link>
        </li>
        <li>
          <Link
            href="/community"
            className="px-4 py-2 rounded-md text-pink-400 hover:text-pink-300 transition-all duration-300 hover:shadow-[0_0_15px_rgba(255,105,180,0.5)] hover:bg-pink-400/10"
          >
            Community
          </Link>
        </li>
        <li>
          <Link
            href="/trading"
            className="px-4 py-2 rounded-md text-cyan-400 hover:text-cyan-300 transition-all duration-300 hover:shadow-[0_0_15px_rgba(0,255,255,0.5)] hover:bg-cyan-400/10"
          >
            Trading & Portfolio
          </Link>
        </li>
        <li>
          <Link
            href="/external-tools"
            className="px-4 py-2 rounded-md text-pink-400 hover:text-pink-300 transition-all duration-300 hover:shadow-[0_0_15px_rgba(255,105,180,0.5)] hover:bg-pink-400/10"
          >
            External Tools
          </Link>
        </li>
      </ul>
    </nav>
  )
}

