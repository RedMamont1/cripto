import Link from 'next/link'

export function Footer() {
  return (
    <footer className="bg-[#0A0A0A] border-t border-gray-800 text-gray-300 p-8 mt-8">
      <div className="container mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-lg font-bold mb-4 text-cyan-400">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/documentation" className="hover:text-cyan-300 transition-colors">
                  Documentation
                </Link>
              </li>
              <li>
                <Link href="/getting-started" className="hover:text-cyan-300 transition-colors">
                  Getting Started
                </Link>
              </li>
              <li>
                <Link href="/resources" className="hover:text-cyan-300 transition-colors">
                  Resources
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-bold mb-4 text-pink-400">Community</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/forum" className="hover:text-pink-300 transition-colors">
                  Forum
                </Link>
              </li>
              <li>
                <Link href="/discord" className="hover:text-pink-300 transition-colors">
                  Discord
                </Link>
              </li>
              <li>
                <Link href="/events" className="hover:text-pink-300 transition-colors">
                  Events
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-bold mb-4 text-cyan-400">Legal</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/terms" className="hover:text-cyan-300 transition-colors">
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="hover:text-cyan-300 transition-colors">
                  Privacy Policy
                </Link>
              </li>
            </ul>
          </div>
        </div>
        <div className="mt-8 pt-8 border-t border-gray-800 text-center text-gray-400">
          <p>&copy; 2023 Your Company Name. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}

