import Link from 'next/link'

export default function Home() {
  return (
    <div className="space-y-12 py-8">
      <h1 className="text-4xl font-bold mb-4 text-center text-white">Welcome to Our Platform</h1>
      
      <section className="bg-[#0A0A0A] rounded-lg p-8 border border-gray-800">
        <h2 className="text-2xl font-semibold mb-6 text-cyan-400">Main Sections</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Link 
            href="/learn" 
            className="block p-6 rounded-lg bg-[#1A1A1A] border border-pink-500/20 text-pink-400 hover:text-pink-300 transition-all duration-300 hover:shadow-[0_0_30px_rgba(255,105,180,0.2)] group"
          >
            <h3 className="text-xl font-semibold mb-2 group-hover:text-pink-300">Learn</h3>
            <p className="text-gray-400">Start your journey with comprehensive tutorials</p>
          </Link>
          
          <Link 
            href="/developers" 
            className="block p-6 rounded-lg bg-[#1A1A1A] border border-cyan-500/20 text-cyan-400 hover:text-cyan-300 transition-all duration-300 hover:shadow-[0_0_30px_rgba(0,255,255,0.2)] group"
          >
            <h3 className="text-xl font-semibold mb-2 group-hover:text-cyan-300">Developers</h3>
            <p className="text-gray-400">Access documentation and developer tools</p>
          </Link>
          
          <Link 
            href="/solutions" 
            className="block p-6 rounded-lg bg-[#1A1A1A] border border-pink-500/20 text-pink-400 hover:text-pink-300 transition-all duration-300 hover:shadow-[0_0_30px_rgba(255,105,180,0.2)] group"
          >
            <h3 className="text-xl font-semibold mb-2 group-hover:text-pink-300">Solutions</h3>
            <p className="text-gray-400">Explore enterprise-ready solutions</p>
          </Link>
        </div>
      </section>

      <section className="bg-[#0A0A0A] rounded-lg p-8 border border-gray-800">
        <h2 className="text-2xl font-semibold mb-6 text-cyan-400">Resource Center</h2>
        <div className="flex gap-4">
          <Link 
            href="/resources" 
            className="px-6 py-3 rounded-md bg-cyan-400/10 text-cyan-400 hover:text-cyan-300 transition-all duration-300 hover:shadow-[0_0_15px_rgba(0,255,255,0.5)]"
          >
            Explore Resources
          </Link>
          <Link 
            href="/interactive" 
            className="px-6 py-3 rounded-md bg-pink-400/10 text-pink-400 hover:text-pink-300 transition-all duration-300 hover:shadow-[0_0_15px_rgba(255,105,180,0.5)]"
          >
            Interactive Tools
          </Link>
        </div>
      </section>
    </div>
  )
}

