import { Navigation } from "../components/Navigation"
import { Footer } from "../components/Footer"

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-[#1A1A1A] text-gray-100">
        <div className="flex flex-col min-h-screen">
          <Navigation />
          <main className="container mx-auto p-4 flex-grow pt-20">{children}</main>
          <Footer />
        </div>
      </body>
    </html>
  )
}



import './globals.css'